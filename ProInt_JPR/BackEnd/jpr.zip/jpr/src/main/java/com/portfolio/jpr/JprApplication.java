package com.portfolio.jpr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JprApplication {

	public static void main(String[] args) {
		SpringApplication.run(JprApplication.class, args);
	}

}
